# CyberBot — Part 3 Setup Guide

Part 3 adds four features to the existing WPF chatbot from Parts 1 & 2:
- 🗒 **Task Assistant** (MySQL-backed)
- 🎮 **Cybersecurity Quiz** (mini-game)
- 🧠 **NLP simulation** (keyword-based intent detection)
- 📋 **Activity Log** (MySQL-backed)

All existing Part 1 & 2 chatbot features (topics, sentiment empathy, memory
nudges, follow-up tips) still work exactly as before — the new features are
layered on top, not a replacement.

## 1. Set up MySQL

You said MySQL Workbench / Installer is already on your machine, so:

1. Open MySQL Workbench and connect to your local server.
2. Open `schema.sql` (included in this project folder) and run it.
   This creates the `cyberbot_db` database with `tasks` and `activity_log`
   tables. (The app will also try to auto-create these on startup if you
   skip this step — but running it manually first is the safest option.)

## 2. Set your password

Open **`DbConfig.cs`** and replace:

```csharp
private const string Password = "YOUR_MYSQL_PASSWORD_HERE";
```

with your actual MySQL root/user password. If your local MySQL has no
password set, leave it as an empty string `""`.

If your MySQL runs on a different port or under a different username,
adjust `Server`, `Port`, and `UserId` in the same file too.

## 3. Restore NuGet packages & build

Open `WpfApp1.sln` in Visual Studio. It references one new package,
**MySqlConnector** (v2.3.7), which NuGet will restore automatically on
build. If it doesn't restore automatically:

```
Tools → NuGet Package Manager → Manage NuGet Packages for Solution →
restore / install MySqlConnector
```

Then build & run as usual (F5).

## 4. What to try

Once the app is running and you've entered your name:

| Try saying...                                   | What happens                          |
|--------------------------------------------------|----------------------------------------|
| `add a task to enable 2FA`                       | Creates a task (no reminder)           |
| `remind me to update my password in 7 days`      | Creates a task with a reminder date    |
| `view my tasks`                                  | Lists all tasks                        |
| `complete task 1`                                | Marks task #1 as done                  |
| `delete task 1`                                  | Removes task #1                        |
| `start quiz`                                     | Begins the 13-question cybersecurity quiz |
| (then) `2` or `true`                             | Answers the current quiz question      |
| `show activity log`                              | Shows the last 10 logged actions       |
| `show full log`                                  | Shows the entire activity history      |
| `what is phishing?` / `password` / `help` / etc. | Original Part 1 & 2 behaviour          |

## Notes on design choices

- **Graceful degradation:** if MySQL isn't reachable (wrong password, server
  not running, etc.), the app doesn't crash. Tasks and the activity log fall
  back to in-memory storage for that session, and a small warning appears
  at startup. You'll see the warning if `DbConfig.cs` still has a placeholder
  or wrong password.
- **NLP intent detection** (`NlpRouter.cs`) sits in front of the original
  `ResponseEngine`. If no task/quiz/log keyword is recognised, input falls
  through unchanged to the Part 1/2 logic — so nothing from before was removed.
- **Quiz** has 13 questions (brief requires 10+), mixing multiple-choice and
  true/false, covering phishing, passwords, browsing, social engineering,
  2FA, malware, and VPNs, with immediate feedback and a final score message.
