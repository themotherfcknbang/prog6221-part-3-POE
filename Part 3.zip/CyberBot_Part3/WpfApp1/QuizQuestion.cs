using System.Collections.Generic;

namespace CyberBot
{
    enum QuestionType { MultipleChoice, TrueFalse }

    class QuizQuestion
    {
        public string Text { get; set; } = "";
        public QuestionType Type { get; set; }
        public List<string> Options { get; set; } = new();
        public int CorrectIndex { get; set; }
        public string Explanation { get; set; } = "";

        public string CorrectAnswerText => Options[CorrectIndex];
    }
}
