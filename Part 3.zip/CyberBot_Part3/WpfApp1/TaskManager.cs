using System;
using System.Collections.Generic;
using MySqlConnector;

namespace CyberBot
{
    /// <summary>
    /// Handles all create/read/update/delete operations for cybersecurity
    /// tasks, backed by the MySQL `tasks` table. Also raises activity-log
    /// entries for every meaningful change.
    /// </summary>
    static class TaskManager
    {
        /// <summary>In-memory fallback store, used only if the database is unavailable.</summary>
        private static readonly List<TaskItem> _memoryTasks = new();
        private static int _memoryNextId = 1;

        // ── Add ──────────────────────────────────────────────────────────
        public static TaskItem AddTask(string title, string? description, DateTime? reminderDate)
        {
            var task = new TaskItem
            {
                Title        = title,
                Description  = description,
                ReminderDate = reminderDate,
                IsCompleted  = false,
                CreatedAt    = DateTime.Now
            };

            if (!Database.IsAvailable)
            {
                task.Id = _memoryNextId++;
                _memoryTasks.Add(task);
            }
            else
            {
                try
                {
                    using var conn = Database.GetConnection();
                    using var cmd  = conn.CreateCommand();
                    cmd.CommandText = @"INSERT INTO tasks (Title, Description, ReminderDate, IsCompleted, CreatedAt)
                                         VALUES (@title, @desc, @reminder, 0, @created);";
                    cmd.Parameters.AddWithValue("@title", title);
                    cmd.Parameters.AddWithValue("@desc", description ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@reminder", reminderDate ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@created", task.CreatedAt);

                    cmd.ExecuteNonQuery();
                    task.Id = (int)cmd.LastInsertedId;
                }
                catch
                {
                    task.Id = _memoryNextId++;
                    _memoryTasks.Add(task);
                }
            }

            string reminderNote = reminderDate.HasValue ? $" (reminder set for {reminderDate.Value:dd MMM yyyy})" : "";
            ActivityLogger.Log($"Task added: \"{title}\"{reminderNote}", ActivityLogger.Category.Task);
            if (reminderDate.HasValue)
                ActivityLogger.Log($"Reminder set for \"{title}\" on {reminderDate.Value:dd MMM yyyy}", ActivityLogger.Category.Reminder);

            return task;
        }

        // ── Read ─────────────────────────────────────────────────────────
        public static List<TaskItem> GetAllTasks()
        {
            if (!Database.IsAvailable)
                return new List<TaskItem>(_memoryTasks);

            var tasks = new List<TaskItem>();
            try
            {
                using var conn = Database.GetConnection();
                using var cmd  = conn.CreateCommand();
                cmd.CommandText = @"SELECT TaskId, Title, Description, ReminderDate, IsCompleted, CreatedAt
                                     FROM tasks
                                     ORDER BY IsCompleted ASC, CreatedAt DESC;";

                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    tasks.Add(new TaskItem
                    {
                        Id           = reader.GetInt32("TaskId"),
                        Title        = reader.GetString("Title"),
                        Description  = reader.IsDBNull(reader.GetOrdinal("Description")) ? null : reader.GetString("Description"),
                        ReminderDate = reader.IsDBNull(reader.GetOrdinal("ReminderDate")) ? null : reader.GetDateTime("ReminderDate"),
                        IsCompleted  = reader.GetBoolean("IsCompleted"),
                        CreatedAt    = reader.GetDateTime("CreatedAt")
                    });
                }
            }
            catch
            {
                return new List<TaskItem>(_memoryTasks);
            }

            return tasks;
        }

        // ── Update: mark complete ───────────────────────────────────────
        public static bool MarkCompleted(int taskId)
        {
            if (!Database.IsAvailable)
            {
                var task = _memoryTasks.Find(t => t.Id == taskId);
                if (task == null) return false;
                task.IsCompleted = true;
                ActivityLogger.Log($"Task #{taskId} marked as completed", ActivityLogger.Category.Task);
                return true;
            }

            try
            {
                using var conn = Database.GetConnection();
                using var cmd  = conn.CreateCommand();
                cmd.CommandText = "UPDATE tasks SET IsCompleted = 1 WHERE TaskId = @id;";
                cmd.Parameters.AddWithValue("@id", taskId);
                int affected = cmd.ExecuteNonQuery();

                if (affected > 0)
                    ActivityLogger.Log($"Task #{taskId} marked as completed", ActivityLogger.Category.Task);

                return affected > 0;
            }
            catch
            {
                return false;
            }
        }

        // ── Delete ───────────────────────────────────────────────────────
        public static bool DeleteTask(int taskId)
        {
            if (!Database.IsAvailable)
            {
                int removed = _memoryTasks.RemoveAll(t => t.Id == taskId);
                if (removed > 0)
                    ActivityLogger.Log($"Task #{taskId} deleted", ActivityLogger.Category.Task);
                return removed > 0;
            }

            try
            {
                using var conn = Database.GetConnection();
                using var cmd  = conn.CreateCommand();
                cmd.CommandText = "DELETE FROM tasks WHERE TaskId = @id;";
                cmd.Parameters.AddWithValue("@id", taskId);
                int affected = cmd.ExecuteNonQuery();

                if (affected > 0)
                    ActivityLogger.Log($"Task #{taskId} deleted", ActivityLogger.Category.Task);

                return affected > 0;
            }
            catch
            {
                return false;
            }
        }

        // ── Display helper ──────────────────────────────────────────────
        public static string FormatTaskList()
        {
            var tasks = GetAllTasks();
            if (tasks.Count == 0)
                return "You don't have any tasks yet. Try: \"Add a task to enable 2FA\"";

            var sb = new System.Text.StringBuilder();
            sb.AppendLine("🗒 Your Cybersecurity Tasks:\n");
            foreach (var t in tasks)
                sb.AppendLine(t.ToDisplayString());

            sb.AppendLine("\nSay \"complete task 3\" or \"delete task 3\" to manage one.");
            return sb.ToString().TrimEnd();
        }
    }
}
