-- ============================================================
--  CyberBot — Part 3 Database Schema
--  Run this once in MySQL Workbench (or any MySQL client)
--  before running the application.
-- ============================================================

CREATE DATABASE IF NOT EXISTS cyberbot_db;
USE cyberbot_db;

-- ── Tasks table ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tasks (
    TaskId        INT AUTO_INCREMENT PRIMARY KEY,
    Title         VARCHAR(150)  NOT NULL,
    Description   VARCHAR(500)  NULL,
    ReminderDate  DATETIME      NULL,
    IsCompleted   TINYINT(1)    NOT NULL DEFAULT 0,
    CreatedAt     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ── Activity log table ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS activity_log (
    LogId         INT AUTO_INCREMENT PRIMARY KEY,
    Action        VARCHAR(300)  NOT NULL,
    Category      VARCHAR(50)   NOT NULL,
    Timestamp     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
);
