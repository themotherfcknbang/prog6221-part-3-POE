using System;
using System.Collections.Generic;
using System.Linq;

namespace CyberBot
{
    /// <summary>
    /// Manages the cybersecurity quiz: question bank, current session state,
    /// scoring, and feedback messages.
    /// </summary>
    class QuizEngine
    {
        private static readonly Random _rng = new();

        private readonly List<QuizQuestion> _questions;
        private int _currentIndex;
        private int _score;
        private bool _awaitingAnswer;

        public bool IsActive { get; private set; }
        public int TotalQuestions => _questions.Count;
        public int CurrentQuestionNumber => _currentIndex + 1;
        public int Score => _score;

        public QuizEngine()
        {
            _questions = BuildQuestionBank().OrderBy(_ => _rng.Next()).ToList();
        }

        // ── Lifecycle ────────────────────────────────────────────────────

        public string Start()
        {
            IsActive        = true;
            _currentIndex   = 0;
            _score          = 0;
            _awaitingAnswer = true;
            ActivityLogger.Log("Quiz started", ActivityLogger.Category.Quiz);
            return BuildQuestionPrompt();
        }

        private string BuildQuestionPrompt()
        {
            var q = _questions[_currentIndex];
            var sb = new System.Text.StringBuilder();

            sb.AppendLine($" Question {CurrentQuestionNumber}/{TotalQuestions}:");
            sb.AppendLine(q.Text);
            sb.AppendLine();

            for (int i = 0; i < q.Options.Count; i++)
                sb.AppendLine($"   {i + 1}. {q.Options[i]}");

            sb.AppendLine("\nType the number (or the answer text) to respond.");
            return sb.ToString().TrimEnd();
        }

        /// <summary>
        /// Processes the user's answer to the current question.
        /// Returns feedback text, and advances to the next question or ends the quiz.
        /// </summary>
        public string SubmitAnswer(string rawAnswer)
        {
            if (!IsActive || !_awaitingAnswer)
                return "There's no active quiz question right now. Type 'start quiz' to begin!";

            var q = _questions[_currentIndex];
            int? chosenIndex = ParseAnswerIndex(rawAnswer, q);

            bool correct = chosenIndex.HasValue && chosenIndex.Value == q.CorrectIndex;
            if (correct) _score++;

            var sb = new System.Text.StringBuilder();
            sb.AppendLine(correct ? " Correct!" : $" Not quite — the correct answer was: {q.CorrectAnswerText}");
            sb.AppendLine($" {q.Explanation}");

            ActivityLogger.Log(
                $"Quiz Q{CurrentQuestionNumber}: {(correct ? "correct" : "incorrect")}",
                ActivityLogger.Category.Quiz);

            _currentIndex++;

            if (_currentIndex >= _questions.Count)
            {
                IsActive        = false;
                _awaitingAnswer = false;
                sb.AppendLine();
                sb.AppendLine(BuildFinalScoreMessage());
                ActivityLogger.Log($"Quiz completed: {_score}/{TotalQuestions}", ActivityLogger.Category.Quiz);
            }
            else
            {
                sb.AppendLine();
                sb.AppendLine(BuildQuestionPrompt());
            }

            return sb.ToString().TrimEnd();
        }

        private string BuildFinalScoreMessage()
        {
            double pct = (double)_score / TotalQuestions * 100;
            string verdict = pct switch
            {
                >= 90 => " Great job! You're a cybersecurity pro!",
                >= 70 => " Solid score! You know your stuff.",
                >= 50 => " Not bad — a bit more practice and you'll be a pro!",
                _     => " Keep learning to stay safe online! Try the quiz again anytime."
            };

            return $" Final Score: {_score}/{TotalQuestions} ({pct:0}%)\n{verdict}";
        }

        private static int? ParseAnswerIndex(string raw, QuizQuestion q)
        {
            raw = raw.Trim().ToLower();

            // Numeric answer, e.g. "2"
            if (int.TryParse(raw, out int num) && num >= 1 && num <= q.Options.Count)
                return num - 1;

            // Text match against option, e.g. "true" or "phishing"
            for (int i = 0; i < q.Options.Count; i++)
                if (q.Options[i].ToLower() == raw || raw.Contains(q.Options[i].ToLower()))
                    return i;

            return null;
        }

        // ── Question bank ────────────────────────────────────────────────
        private static List<QuizQuestion> BuildQuestionBank() => new()
        {
            new QuizQuestion
            {
                Text = "What is 'phishing'?",
                Type = QuestionType.MultipleChoice,
                Options = new() { "A type of computer virus", "Tricking someone into revealing personal info", "A firewall setting", "A type of strong password" },
                CorrectIndex = 1,
                Explanation = "Phishing is a social engineering attack where attackers impersonate trusted sources to steal information."
            },
            new QuizQuestion
            {
                Text = "A strong password should be at least 12 characters long.",
                Type = QuestionType.TrueFalse,
                Options = new() { "True", "False" },
                CorrectIndex = 0,
                Explanation = "Longer passwords (12+ characters) are exponentially harder to crack."
            },
            new QuizQuestion
            {
                Text = "Which of these is the safest way to store passwords?",
                Type = QuestionType.MultipleChoice,
                Options = new() { "Written on a sticky note", "The same password everywhere", "A reputable password manager", "Saved in a plain text file" },
                CorrectIndex = 2,
                Explanation = "Password managers generate and securely store unique, strong passwords for every account."
            },
            new QuizQuestion
            {
                Text = "It's safe to click a link in an email if it looks like it's from your bank.",
                Type = QuestionType.TrueFalse,
                Options = new() { "True", "False" },
                CorrectIndex = 1,
                Explanation = "Attackers often spoof trusted brands. Always verify the sender and hover over links before clicking."
            },
            new QuizQuestion
            {
                Text = "What does 'HTTPS' in a website address indicate?",
                Type = QuestionType.MultipleChoice,
                Options = new() { "The site is free to use", "The connection is encrypted", "The site loads faster", "The site has no ads" },
                CorrectIndex = 1,
                Explanation = "HTTPS encrypts the data sent between your browser and the website, protecting it from interception."
            },
            new QuizQuestion
            {
                Text = "Two-Factor Authentication (2FA) adds an extra layer of security beyond your password.",
                Type = QuestionType.TrueFalse,
                Options = new() { "True", "False" },
                CorrectIndex = 0,
                Explanation = "2FA requires a second proof of identity (like a code from your phone), blocking most account takeovers even if your password is stolen."
            },
            new QuizQuestion
            {
                Text = "Which is an example of 'social engineering'?",
                Type = QuestionType.MultipleChoice,
                Options = new() { "Updating your antivirus software", "A scammer pretending to be IT support to get your password", "Installing a VPN", "Enabling a firewall" },
                CorrectIndex = 1,
                Explanation = "Social engineering manipulates people psychologically into giving up confidential information or access."
            },
            new QuizQuestion
            {
                Text = "Public Wi-Fi networks are always safe for online banking.",
                Type = QuestionType.TrueFalse,
                Options = new() { "True", "False" },
                CorrectIndex = 1,
                Explanation = "Public Wi-Fi is often unencrypted, making it easier for attackers to intercept your data. Use a VPN or avoid sensitive tasks on public networks."
            },
            new QuizQuestion
            {
                Text = "What should you do if you receive an unexpected, urgent request for money from a 'family member' over text?",
                Type = QuestionType.MultipleChoice,
                Options = new() { "Send the money immediately", "Verify by calling them directly first", "Reply with your bank details", "Ignore and delete without checking" },
                CorrectIndex = 1,
                Explanation = "Scammers exploit urgency. Always verify unusual requests through a separate, trusted channel before acting."
            },
            new QuizQuestion
            {
                Text = "Ransomware is a type of malware that encrypts your files and demands payment.",
                Type = QuestionType.TrueFalse,
                Options = new() { "True", "False" },
                CorrectIndex = 0,
                Explanation = "Ransomware locks you out of your own files until a ransom is paid — regular backups are the best defence."
            },
            new QuizQuestion
            {
                Text = "Which of these is the BEST practice for browser security?",
                Type = QuestionType.MultipleChoice,
                Options = new() { "Disabling all updates", "Installing extensions from unknown sources", "Keeping your browser updated", "Ignoring certificate warnings" },
                CorrectIndex = 2,
                Explanation = "Browser updates patch known security vulnerabilities, closing doors attackers might exploit."
            },
            new QuizQuestion
            {
                Text = "Using the same password across multiple accounts is a good security habit.",
                Type = QuestionType.TrueFalse,
                Options = new() { "True", "False" },
                CorrectIndex = 1,
                Explanation = "If one account is breached, reused passwords let attackers access all your other accounts via 'credential stuffing'."
            },
            new QuizQuestion
            {
                Text = "A VPN primarily helps protect your privacy by...",
                Type = QuestionType.MultipleChoice,
                Options = new() { "Speeding up your internet", "Encrypting your internet traffic", "Removing viruses", "Blocking all ads" },
                CorrectIndex = 1,
                Explanation = "A VPN encrypts your traffic and masks your IP address, which is especially useful on public networks."
            },
        };
    }
}
