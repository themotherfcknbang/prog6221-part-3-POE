using System;

namespace CyberBot
{
    /// <summary>
    /// Represents a single cybersecurity-related task the user wants to track,
    /// e.g. "Enable two-factor authentication".
    /// </summary>
    class TaskItem
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";
        public string? Description { get; set; }
        public DateTime? ReminderDate { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime CreatedAt { get; set; }

        /// <summary>Friendly one-line summary for display in chat / task list.</summary>
        public string ToDisplayString()
        {
            string status   = IsCompleted ? "✅" : "🔲";
            string reminder = ReminderDate.HasValue
                ? $"  ⏰ {ReminderDate.Value:dd MMM yyyy}"
                : "";
            string desc = string.IsNullOrWhiteSpace(Description)
                ? ""
                : $"\n      {Description}";

            return $"{status} #{Id} — {Title}{reminder}{desc}";
        }
    }
}
